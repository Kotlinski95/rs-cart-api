
INSERT INTO carts (id, user_id, created_at, updated_at, status)
VALUES 
  ('d5d5a5a8-5f5f-4d4d-9c9c-3a3a3a3a3a3a', 'b8b8b8b8-c7c7-c6c6-c5c5-a9a9a9a9a9a9', '2022-01-01', '2022-01-02', 'OPEN'),
  ('e6e6e6e6-5f5f-4d4d-9c9c-3a3a3a3a3a3a', 'b8b8b8b8-c7c7-c6c6-c5c5-a9a9a9a9a9a9', '2022-01-02', '2022-01-03', 'ORDERED'),
  ('f7f7f7f7-5f5f-4d4d-9c9c-3a3a3a3a3a3a', 'd4d4d4d4-c3c3-c2c2-c1c1-b0b0b0b0b0b0', '2022-02-01', '2022-02-02', 'OPEN');