
INSERT INTO cart_items (cart_id, product_id, count)
VALUES 
  ('d5d5a5a8-5f5f-4d4d-9c9c-3a3a3a3a3a3a', 'a1a1a1a1-b2b2-b3b3-b4b4-c5c5c5c5c5c5', 2),
  ('d5d5a5a8-5f5f-4d4d-9c9c-3a3a3a3a3a3a', 'd4d4d4d4-c3c3-c2c2-c1c1-b0b0b0b0b0b0', 1),
  ('e6e6e6e6-5f5f-4d4d-9c9c-3a3a3a3a3a3a', 'd4d4d4d4-c3c3-c2c2-c1c1-b0b0b0b0b0b0', 3),
  ('f7f7f7f7-5f5f-4d4d-9c9c-3a3a3a3a3a3a', 'a1a1a1a1-b2b2-b3b3-b4b4-c5c5c5c5c5c5', 5);
